package com.laptopshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptopShopManagement2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

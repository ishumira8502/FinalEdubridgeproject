
package com.laptopshop.model;


import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.OneToOne;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name="billing")

public class Billing {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Bill_Id")
	private long billId;
	
	@Column(name="Payment_Date")
	private String paymentDate;
	
	@Column(name="Paid_Amount")
	private long paidAmount;
	
	


	@Column(name="Total_Amount")
	private long totalAmount;
	
	@Column(name="Laptop_BrandName")
	private String laptopBrandName;
	
	@Column(name="laptop_Specification")
	private String laptopSpecification;
	
	@Column(name="Customer_Name")
	private String customerName;
	
	@Column(name="Customer_Address")
	private String customerAddress;
	
	@Column(name="Customer_EmailId")
	private String customerEmailId;
	
	@Column(name="Customer_PhoneNo")
	private String customerPhoneNo; 
	
	@Column(name="Laptop_ItemPrice")
	private String laptopItemPrice;
	
	@OneToOne
	@JoinColumn(name="Laptop_ModelId")
	@JsonIgnore
	private LaptopDetails laptopdetails;
	
	@OneToOne(cascade=CascadeType.MERGE)
	@JoinColumn(name="Customer_Id")
	@JsonIgnore
	private Customer customer;

	public long getBillId() {
		return billId;
	}

	public void setBillId(long billId) {
		this.billId = billId;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public long getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(long paidAmount) {
		this.paidAmount = paidAmount;
	}

	public long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getLaptopBrandName() {
		return laptopBrandName;
	}

	public void setLaptopBrandName(String laptopBrandName) {
		this.laptopBrandName = laptopBrandName;
	}

	public String getLaptopSpecification() {
		return laptopSpecification;
	}

	public void setLaptopSpecification(String laptopSpecification) {
		this.laptopSpecification = laptopSpecification;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

	public String getCustomerPhoneNo() {
		return customerPhoneNo;
	}

	public void setCustomerPhoneNo(String customerPhoneNo) {
		this.customerPhoneNo = customerPhoneNo;
	}

	public String getLaptopItemPrice() {
		return laptopItemPrice;
	}

	public void setLaptopItemPrice(String laptopItemPrice) {
		this.laptopItemPrice = laptopItemPrice;
	}

	public LaptopDetails getLaptopdetails() {
		return laptopdetails;
	}

	public void setLaptopdetails(LaptopDetails laptopdetails) {
		this.laptopdetails = laptopdetails;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/*public Billing(long billId, Date paymentDate, long paidAmount, long totalAmount, String laptopBrandName,
			String laptopSpecification, String customerName, String customerAddress, String customerEmailId,
			String customerPhoneNo, String laptopItemPrice, LaptopDetails laptopdetails, Customer customer) {
		super();
		this.billId = billId;
		this.paymentDate = paymentDate;
		this.paidAmount = paidAmount;
		this.totalAmount = totalAmount;
		this.laptopBrandName = laptopBrandName;
		this.laptopSpecification = laptopSpecification;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerEmailId = customerEmailId;
		this.customerPhoneNo = customerPhoneNo;
		this.laptopItemPrice = laptopItemPrice;
		this.laptopdetails = laptopdetails;
		this.customer = customer;
	}*/
	 public Billing() {}




}

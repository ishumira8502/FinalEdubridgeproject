package com.laptopshop.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.laptopshop.model.Billing;
import com.laptopshop.service.BillingService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/billings")

public class BillingController {
	@Autowired
	private BillingService billingservice;
	
		public BillingController(BillingService billingservice) {
		super();
		this.billingservice = billingservice;
		
	}
	//making billing
	@PostMapping("{customerId}/{laptopModelId}")
	public ResponseEntity<Billing> addBilling( @RequestBody Billing billing,@PathVariable long customerId,@PathVariable long laptopModelId)
	{

		return new ResponseEntity<Billing>(billingservice.addBilling(billing,customerId,laptopModelId),HttpStatus.CREATED);
	}
	//getting list of billings
	@GetMapping  
	public List<Billing> getAllBillings()
	{
		return billingservice.getAllBillings();
}

	//to get billing by billing id(for receipt)

	@GetMapping("{billId}")
	public ResponseEntity<Billing> getBillingById(@PathVariable("billId") long billId)
	{
		return new ResponseEntity<Billing>(billingservice.getBillingById(billId),HttpStatus.OK);
	}
	
	
// to delete payement
	@DeleteMapping("{billId}")
	public ResponseEntity<Boolean> deleteBilling(@PathVariable("billId") long billId)
	{
		billingservice.deleteBilling(billId);
		boolean flag=true;
		return new ResponseEntity<Boolean>(flag,HttpStatus.OK);
	}
	

}
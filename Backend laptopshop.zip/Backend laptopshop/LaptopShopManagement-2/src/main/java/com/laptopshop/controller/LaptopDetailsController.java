package com.laptopshop.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.laptopshop.model.LaptopDetails;
import com.laptopshop.service.LaptopDetailsService;

@CrossOrigin(origins="http://localhost:4200")
@RestController 
@RequestMapping("/api/laptopdetails")

public class LaptopDetailsController {
	
	
	@Autowired
	private LaptopDetailsService laptopdetailsservice;

	public LaptopDetailsController(LaptopDetailsService laptopdetailsservice) {
		super();
		this.laptopdetailsservice = laptopdetailsservice;
	}
	
//to add laptopdetails
	@PostMapping("{userId}")
	public ResponseEntity<LaptopDetails> addLaptopDetail(@Valid @RequestBody LaptopDetails laptopDetails,@PathVariable long userId)
{
	System.out.println("********");
		return new ResponseEntity<LaptopDetails>(laptopdetailsservice.addLaptopDetails(laptopDetails,userId),HttpStatus.CREATED);
}
	//to get all laptopdetails
	@GetMapping  ("/") 
	public List<LaptopDetails> getAllLaptopDetails()
	{
		return laptopdetailsservice.getAllLaptopDetails();
}
	//to get particular laptopdetails
	@GetMapping("laptopDetails/{laptopModelId}")
	public ResponseEntity<LaptopDetails> getLaptopDetailsById(@PathVariable("laptopModelId") long laptopModelId)
	{
		return new ResponseEntity<LaptopDetails>(laptopdetailsservice.getLaptopDetailsById(laptopModelId),HttpStatus.OK);
	}
	//update LaptopDetails
	@PutMapping("{laptopModelId}")
	public ResponseEntity<LaptopDetails> updateLaptopDetails(@Valid @PathVariable("laptopModelId") long laptopModelId, @RequestBody LaptopDetails laptopDetails)
	{
		return new ResponseEntity<LaptopDetails> (laptopdetailsservice.updateLaptopDetails(laptopDetails, laptopModelId),HttpStatus.OK);
	}
	//delete laptopdetails
	@DeleteMapping("{laptopModelId}")
	public ResponseEntity<Boolean> deleteLaptopDetails(@PathVariable long laptopModelId)
	{
		laptopdetailsservice.deleteLaptopDetails(laptopModelId);
		boolean flag=true;
		return new ResponseEntity<Boolean>(flag,HttpStatus.OK);
	}

}
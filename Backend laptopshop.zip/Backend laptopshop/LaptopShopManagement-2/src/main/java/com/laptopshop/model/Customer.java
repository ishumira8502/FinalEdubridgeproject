package com.laptopshop.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="customer_table")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="Customer_Id")
  private long customerId;
	
	@Column(name="Customer_Name")
	@NotEmpty
	@Size(min=3 , message="lastName must contain atleast 3 characters")
	private String customerName;
	
	@Column(name="Customer_Addresss")
	@NotEmpty
	private String customerAddress;
	
	@Column(name="Customer_EmailId",unique=true)
	@NotEmpty
	@Email(message="Email is not valid")
	public String customerEmailId;
	
	@Column(name="Customer_PhoneNo")
	@NotEmpty
	@Size(min=10 ,max=10, message="PhoneNo must contain 10 digits")
	private String customerPhoneNo;
	
	@Column(name="Customer_Password")
	@NotEmpty
	@Size(min=8 , message="Password length must be 8 and contain uppercase,lowercase ,digits")
	@Pattern(regexp="(?=.*\\d)(?=.[a-z])(?=.*[A-Z]).{8,}")
	public String customerPassword;
	
  @OneToOne(cascade=CascadeType.MERGE)
  @JsonIgnore
  @JoinColumn(name="billingId")
  private Billing billing;  
  @OneToOne(cascade=CascadeType.MERGE)
  @JsonIgnore
  @JoinColumn(name="laptopDetailsId")
  private LaptopDetails laptopdetails;
  
  

/*public Customer(long customerId,
		@NotEmpty @Size(min = 3, message = "lastName must contain atleast 3 characters") String customerName,
		@NotEmpty String customerAddress, @NotEmpty @Email(message = "Email is not valid") String customerEmailId,
		@NotEmpty @Size(min = 10, max = 10, message = "PhoneNo must contain 10 digits") String customerPhoneNo,
		@NotEmpty @Size(min = 8, message = "Password length must be 8 and contain uppercase,lowercase ,digits") @Pattern(regexp = "(?=.\\d)(?=.[a-z])(?=.*[A-Z]).{8,}") String customerPassword,
		Billing billing, LaptopDetails laptopdetails) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerAddress = customerAddress;
	this.customerEmailId = customerEmailId;
	this.customerPhoneNo = customerPhoneNo;
	this.customerPassword = customerPassword;
	this.billing = billing;
	this.laptopdetails = laptopdetails;
}*/
  public Customer() {}



public long getCustomerId() {
	return customerId;
}

public void setCustomerId(long customerId) {
	this.customerId = customerId;
}

public String getCustomerName() {
	return customerName;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public String getCustomerAddress() {
	return customerAddress;
}

public void setCustomerAddress(String customerAddress) {
	this.customerAddress = customerAddress;
}

public String getCustomerEmailId() {
	return customerEmailId;
}

public void setCustomerEmailId(String customerEmailId) {
	this.customerEmailId = customerEmailId;
}

public String getCustomerPhoneNo() {
	return customerPhoneNo;
}

public void setCustomerPhoneNo(String customerPhoneNo) {
	this.customerPhoneNo = customerPhoneNo;
}

public String getCustomerPassword() {
	return customerPassword;
}

public void setCustomerPassword(String customerPassword) {
	this.customerPassword = customerPassword;
}

public Billing getBilling() {
	return billing;
}

public void setBilling(Billing billing) {
	this.billing = billing;
}

public LaptopDetails getLaptopdetails() {
	return laptopdetails;
}

public void setLaptopdetails(LaptopDetails laptopdetails) {
	this.laptopdetails = laptopdetails;
}


  
  

	
}
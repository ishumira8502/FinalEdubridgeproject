package com.laptopshop.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.laptopshop.model.Users;
import com.laptopshop.service.UsersService;

@CrossOrigin(origins="http://localhost:4200")
@RestController  

@RequestMapping("/api/users")

public class UsersController {
	
	@Autowired
	private UsersService usersservice;

	public UsersController( UsersService usersservice) {
		super();
		this.usersservice = usersservice;
	}
	//users register
	@PostMapping("/register")
	public ResponseEntity<Users > saveUsers(@Valid @RequestBody  Users users)
	{
	System.out.println("users register "+users);
		return new ResponseEntity<Users>(usersservice.saveUsers(users),HttpStatus.CREATED);
	}
	//users login
	@PostMapping("/login")
	public  ResponseEntity<Users> loginUsers( @RequestBody Users users)
	{
	return new ResponseEntity<Users>(usersservice.loginUsers(users),HttpStatus.OK);
		
}
}

package com.laptopshop.serviceImpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptopshop.exception.LaptopDetailsNotFoundException;
import com.laptopshop.model.LaptopDetails;
import com.laptopshop.model.Users;
import com.laptopshop.repository.LaptopDetailsRepository;
import com.laptopshop.service.LaptopDetailsService;
import com.laptopshop.service.UsersService;

@Service
public class LaptopDetailsServiceImpl implements LaptopDetailsService {
	
	
	@Autowired
	private LaptopDetailsRepository laptopdetailsRepository;
	@Autowired
	private UsersService usersservice;

	
	public LaptopDetailsServiceImpl(LaptopDetailsRepository laptopdetailsRepository) {
		super();
		this.laptopdetailsRepository = laptopdetailsRepository;
	}



	  @Override
	public LaptopDetails addLaptopDetails(LaptopDetails laptopdetails,long userId) {
           Users users=usersservice.getUserById(userId);
           laptopdetails.setUsers(users);
		
		return laptopdetailsRepository.save(laptopdetails);
	}  



	@Override
	public List<LaptopDetails> getAllLaptopDetails() {
		return laptopdetailsRepository.findAll();
		
	}



	@Override
	public LaptopDetails getLaptopDetailsById(long laptopModelId) {
		
		return laptopdetailsRepository.findById(laptopModelId).orElseThrow(()->new LaptopDetailsNotFoundException("LaptopDetails","Id",laptopModelId));
	}



	@Override
	public LaptopDetails updateLaptopDetails(LaptopDetails laptopDetails, long laptopModelId) {
		LaptopDetails existingLaptopDetails=laptopdetailsRepository.findById(laptopModelId).orElseThrow(()->new LaptopDetailsNotFoundException(" LaptopDetails","Id",laptopModelId));
		existingLaptopDetails.setLaptopBrandName(laptopDetails.getLaptopBrandName());
		existingLaptopDetails.setLaptopSpecification(laptopDetails.getLaptopSpecification());
		existingLaptopDetails.setLaptopOs(laptopDetails.getLaptopOs());
		existingLaptopDetails.setLaptopItemPrice(laptopDetails.getLaptopItemPrice());
		existingLaptopDetails.setLaptopWarrantyPeriod(laptopDetails.getLaptopWarrantyPeriod());
		
		laptopdetailsRepository.save(existingLaptopDetails);
		return existingLaptopDetails;
	}



	@Override
	public void deleteLaptopDetails(long laptopModelId) {
		laptopdetailsRepository.findById(laptopModelId).orElseThrow(()->new LaptopDetailsNotFoundException("LaptopDetails","Id",laptopModelId));
		laptopdetailsRepository.deleteById(laptopModelId);
		
	}

}
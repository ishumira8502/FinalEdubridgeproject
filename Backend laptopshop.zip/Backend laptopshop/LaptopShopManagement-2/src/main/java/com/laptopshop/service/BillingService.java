package com.laptopshop.service;


import java.util.List;

import com.laptopshop.model.Billing;



public interface BillingService {
	Billing addBilling(Billing billing,long customerId,long laptopModelId);
	List<Billing> getAllBillings();
	Billing getBillingById(long billId);
	void deleteBilling(long billId);
	public List<Billing> getAllBillingByLaptopModelId(long laptopModelId);

}